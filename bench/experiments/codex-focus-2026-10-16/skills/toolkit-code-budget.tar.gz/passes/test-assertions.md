# Test assertions

Own the semantic correctness of changed tests, including test blocks in production files.
Identify the claimed behavior, actual stimulus, state before the action, and the assertions.
Derive expected values from the relevant contract and actual state/owner transitions, not from
the current assertion or a passing run. A new assertion can encode a pre-existing implementation
defect; report the assertion and distinguish the older bug. For a regression claim, show a
specific wrong behavior that the test still accepts or correct behavior it rejects. A predicate
already true before the action or a different guard producing the same error may fail to
distinguish the intended transition. Acceptance tests may legitimately pass at base; absent
extra test cases alone are not defects. Trace only the production code needed to establish these
proofs. Runtime liveness, general cleanup, compilation, repository rules and documentation have
other reviewers, though a concrete incidental finding is welcome. Return verified assertion or
stimulus defects and named gaps within three batched reads. Do not consult peer reports.
