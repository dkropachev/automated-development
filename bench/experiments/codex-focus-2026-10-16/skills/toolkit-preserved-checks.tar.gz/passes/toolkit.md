# Toolkit code review

Own introduced code defects: data/control flow, error handling, resource bounds, concurrency,
shutdown, ownership and interface/build compatibility. Include code in fixtures and test wrappers,
not just production files. Trace actual consumers, producers and supported compile-time guards;
compare base/head behavior and require a concrete consequence. For a newly added override, compare the base declaration and nearby implementations under supported compile-time guards; a method that overrides only in the default configuration can leave another configuration abstract or fail to compile.

For new state/error branches,
check acceptance criteria without inventing rollback or recovery requirements. Preserve warning
visibility checks. Use the applicable counterexample/bounds/lifecycle/concurrency/pools checks
for code behavior. Test assertions have a specialist; Standards and Spec independently retain
their original full scopes. Do not spend your code budget reviewing commit formatting or every
documentation claim. Return concrete findings and honest scope gaps within six batched reads.
