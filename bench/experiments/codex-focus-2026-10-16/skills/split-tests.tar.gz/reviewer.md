# Reviewer evidence contract

Report verified issues in the proposed change: introduced code defects, concrete factual contradictions in changed documentation or comments, unmet explicit acceptance criteria, and violations of applicable repository rules. A documentation defect needs a source-backed counterexample, not a runtime failure; do not discard it merely because its severity is low or the code executes correctly. For an unmet acceptance criterion, distinguish the existing behavior from what the PR explicitly promises to fix; do not describe an unchanged pre-existing exposure as a newly introduced regression. Apply these definitions when discovering candidates and when the parent filters them. Do not propose fixes, patches, implementation plans, simplifications, or speculative maintenance suggestions. Omit matters of taste and hypothetical future problems without a current counterexample or rule violation.

Use distinct issue categories: runtime defect, test defect, factual documentation defect, repository-rule violation, diagnostic regression, and unmet explicit acceptance criterion. A test defect can exist while the happy path passes: identify the specific wrong production behavior its claimed regression check would still accept, or the assertion/failure/cleanup path that misbehaves. A new test named after a transition must actually stimulate and distinguish that transition. Do not demand unrelated integration coverage merely because a unit fixture uses mocks or manual setup. Acceptance tests may correctly pass at base; distinguish them from a false claim that every test reproduces an old defect.

Test-failure safety is its own obligation. A newly added wait without a local failure bound or
an assertion path bypassing required cleanup can be reported even if the happy path passes.
State any external harness deadline and distinguish missing local protection from an actual
production hang. Do not invent a trigger to justify the test gap. Before claiming a signal can
never arrive, trace all callers of its producer, including alternate shutdown/finally paths;
one caller skipping an operation does not prove no caller performs it. Likewise, do not claim
missing cleanup from an omitted explicit finish alone if a destructor or runtime supplies it.


Match the verdict to the issue category; do not disprove a different, easier claim:

| Category | Evidence required | Invalid dismissal or overreach |
| --- | --- | --- |
| Runtime defect | Concrete changed path and consequence, compared with base | A different pre-existing failure does not disprove a newly affected path. |
| Test defect | Claimed behavior versus assertions/stimulus, or a concrete bad failure/cleanup path | A passing happy path or cleanup only on success does not establish failure safety. Do not demand unrelated integration coverage. |
| Repository rule | Exact applicable rule, its scope, and the code violating that predicate | Absence of a race/crash does not waive an ownership rule; rejection needs an applicable exception or evidence of compliance. |
| Factual documentation | Counterexample to the assertion in its actual context | Constant bookkeeping is not a counterexample to a dimension-dependent storage claim. Conversely, no runtime failure is needed to report a provably false numerical assertion. |
| Diagnostic regression | Visibility at the same relevant configuration before and after, and how callers otherwise learn of failure | Requiring debug logging to be enabled does not preserve visibility at INFO/WARN. Do not invent an undocumented default setting. |
| Explicit acceptance criterion | Quote the promised condition and show its violation within that condition | A count/size bound is not a promise of complete semantic validation. Preferred encoder output alone does not prove that a shorter representation is invalid. |

Use the same predicate and configuration in findings and `No finding` reasons. Keep uncertainty
explicit where contextual meaning or rule applicability cannot be resolved. These categories do
not authorize suggestions or inflate duplicates; each reported assertion still needs its own proof.


A documentation counterexample must contradict the assertion in its surrounding context, using the implementation's actual object identities and state meanings. Trace identity changes and predicates that may already be true; do not substitute a required action for a state condition. A later reference to the same variable name does not prove it denotes the same pending object. If the evidence supports a coherent interpretation matching the implementation, treat alternative wording as ambiguity rather than a verified defect unless the specification makes that interpretation impossible.

For each factual claim, preserve its quantifier, subject, and conditions when deciding whether it is true. Evidence for some paths does not establish every path; correct arithmetic on a platform does not establish that the tested code can run there. A pre-existing failure in one path does not rule out a newly affected path: compare the concrete base/head counterexample. A `No finding` disposition must establish the original proposition, not a narrower replacement. Keep a wrong numerical comment as a documentation finding with its own line and corrected quantity, even when the same counterexample also supports a code finding; merge equivalent documentation assertions across passes, not documentation obligations into unrelated code findings.


Review only your assigned subject, tracing adjacent code where its proof requires it. Other subjects have independent owners. Do not repeat their whole review. A concrete issue noticed incidentally may be returned with its evidence; do not expand into another lane's checklist. Read this contract, your brief, and relevant checks in one batched first call with the pinned diff. Check references are conditional obligations within your assigned subject, not permission to expand scope. No tests, builds, edits, formatters, posting, model subprocesses, additional agents, or Git checkout/switch/reset/stash/worktree. Do not write scratch files. All reads count toward your assigned budget.

Return each verified finding with category, exact assertion, changed line, trigger, consequence, base/head comparison, contrary evidence, and the appropriate report axis (Toolkit, Standards or Spec). Name unexamined parts of your responsibility. Missing coverage alone is not a defect: show a false assertion, a failure/cleanup path that misbehaves, a regression check that accepts the specific behavior it promises to reject, or an explicit unmet requirement. Do not limit the number of supported findings or drop low-severity facts.
