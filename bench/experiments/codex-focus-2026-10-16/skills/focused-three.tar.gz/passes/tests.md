# Tests

First assess stimulus and expected values, then execution safety. Allocate the six reads to both; do not spend the entire budget retracing one wait or fixture. Reuse overlapping source already read.

# Test semantics

Own the meaning of changed test cases, including tests embedded in production files. For each case, identify the promise under test, the actual stimulus, the state before the action, and the observations after it. Derive the correct expected result from the operation's contract and real state transitions, not from the current assertion or the fact that the test passes. Account for relevant owners, counters and pending work when calculating the observed state. A new assertion can codify a pre-existing defect; distinguish the introduced assertion from the old implementation issue.

For regression claims, identify a concrete wrong behavior that the assertion still accepts or correct behavior that it rejects. Check whether the observed predicate was already true before the operation, whether an older guard can impersonate the new one, and whether the claimed failure must actually be observed. Acceptance cases may pass before the fix. Missing extra cases alone is not a finding unless an explicit coverage claim is false. Read relevant lifecycle/pools/bounds checks for these questions only. Also cover execution safety below, after assessing test stimulus and expected values. Return verified semantic defects and unresolved proof gaps.

# Test execution and failure safety

Own whether changed test code and fixtures compile and execute safely in supported configurations. Verify changed interfaces and wrappers against actual declarations and compile-time guards. Trace waits to all producers and bounds, including external harness limits. Inspect setup, assertion failure, unexpected exceptions, cancellation, deferred cleanup, destruction order and runtime teardown. Check callback context and captured-state lifetime when they affect execution.

For cleanup claims, identify the resource or incorrect failure that actually survives the failure path. An omitted explicit cleanup call alone is insufficient if destructors or runtime teardown supply cleanup; distinguish graceful cleanup from a required correctness condition. For waits, show the reachable stalled path and absence of the relevant local bound without inventing a producer failure. Do not demand unrelated missing test cases. Preserve the semantic findings from the first part of your review. Use relevant lifecycle/concurrency/pools references only for execution safety. Return concrete defects and scoped unexamined gaps.
